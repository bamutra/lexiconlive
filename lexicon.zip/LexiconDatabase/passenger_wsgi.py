import os
import sys


from LexiconDatabase.wsgi import application
